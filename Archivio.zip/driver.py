from source.zOld2 import module12

if __name__ == "__main__":
    m=module12()
    m.name()
