echo 0 > /sys/bus/usb/devices/2-1/authorized
echo 1 > /sys/bus/usb/devices/2-1/authorized
